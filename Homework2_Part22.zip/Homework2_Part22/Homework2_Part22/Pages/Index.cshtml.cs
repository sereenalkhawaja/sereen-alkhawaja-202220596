﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.Sqlite; 
using System.Collections.Generic;
using System.IO;

namespace Homework2_Part22.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public string Name { get; set; }
        [BindProperty]
        public string Mobile { get; set; }
        [BindProperty]
        public string Address { get; set; }

        public string Message { get; set; }

        public List<PersonInfo> PersonsList { get; set; } = new List<PersonInfo>();

        public class PersonInfo
        {
            public string Name { get; set; }
            public string Mobile { get; set; }
            public string Address { get; set; }
        }

        // إعداد الاتصال
        private string connectionString = "Data Source=MyDatabase.db";

        public void OnGet()
        {
            CreateDatabase();
            LoadData();
        }

        public IActionResult OnPostSave()
        {
            using (var conn = new SqliteConnection(connectionString))
            {
                conn.Open();
                string sql = "INSERT INTO Person (Name, Mobile, Address) VALUES (@n, @m, @a)";
                using (var cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@n", Name);
                    cmd.Parameters.AddWithValue("@m", Mobile);
                    cmd.Parameters.AddWithValue("@a", Address);
                    cmd.ExecuteNonQuery();
                }
            }
            Message = "Saved Successfully!";
            LoadData();
            return Page();
        }

        public IActionResult OnPostDelete()
        {
            using (var conn = new SqliteConnection(connectionString))
            {
                conn.Open();
                string sql = "DELETE FROM Person WHERE Name = @n";
                using (var cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@n", Name);
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0) Message = "Deleted Successfully!";
                    else Message = "Name not found!";
                }
            }
            LoadData();
            return Page();
        }

        private void LoadData()
        {
            PersonsList.Clear();
            using (var conn = new SqliteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Person";
                using (var cmd = new SqliteCommand(sql, conn))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            PersonsList.Add(new PersonInfo
                            {
                                Name = reader["Name"].ToString(),
                                Mobile = reader["Mobile"].ToString(),
                                Address = reader["Address"].ToString()
                            });
                        }
                    }
                }
            }
        }

        private void CreateDatabase()
        {
            
            using (var conn = new SqliteConnection(connectionString))
            {
                conn.Open();
               
                string sql = "CREATE TABLE IF NOT EXISTS Person (Name TEXT, Mobile TEXT, Address TEXT)";
                using (var cmd = new SqliteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}